//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L4H" //  Level name
        super.viewDidLoad()
    }
    
    override func run() {
        
        searchFirstangle()
        serchClearfront()
        serchNextcandy()
        turnLeft()
        serchNextcandy()
        
    } //end Run
    
    // start block functions
    
    func serchNextcandy() {
        while frontIsClear {
            move()
            if candyPresent {
                back()
                pick()
                move()
                put()
                move()
            }
            else if noCandyPresent, frontIsBlocked {
                put()
                back()
                move()
            }
            if candyPresent {
                back()
                pick()
                move()
                pick()
                //               back() // четные не четные
                //               move() // четные не четные
                break
            }
        }
    }
    
    func putCandyandback() {
        if noCandyPresent, frontIsClear {
            put()
            back()
        }
    }
    
    func searchFirstangle () {
        while frontIsClear
        {
            move()
            if frontIsBlocked
            {
                turnRight()
                while frontIsClear {
                    move()
                }
            }
        }
    }
    
    func centerStop () {
        while frontIsClear {
            if candyPresent {
                back()
                move()
                if candyPresent {
                    break
                }
            }
        }
    }
    
    func serchClearfront() {
        while  frontIsBlocked {
            if frontIsClear {
                break
            }
            else {
                turnRight()
            }
        }
    }
    
    func back() {
        turnRight()
        turnRight()
    }
    func turnLeft() {
        turnRight()
        turnRight()
        turnRight()
    }
    // end functions
    
} // End controller
