//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L2C" //  Level name
        super.viewDidLoad()
    }
    
    override func run() {
        for _ in 0...7{
            findPick()
            riseUP()
            uTurn()
            comeDown()
        }
      move()
    }
    
    func turnLeft() {
        turnRight()
        turnRight()
        turnRight()
    }
    
    func findPick() {
        while frontIsClear {
            move()
        }
        turnRight()
    }
    
    func riseUP() {
        while leftIsBlocked {
            move()
        }
    }
    
    func uTurn() {
        turnLeft()
        move()
        turnLeft()
    }
    
    func comeDown() {
        while frontIsClear {
            move()
        }
        turnRight()
    }
    
}
