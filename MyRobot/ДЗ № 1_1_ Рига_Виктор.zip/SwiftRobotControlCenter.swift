//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L22H" //  Level name
        super.viewDidLoad()
    }
    
    override func run() {
        turnLeft()
        while rightIsClear, frontIsClear {
            clearCandy()
            turnBack()
            putThecandy()
            put()
            turnLeft()
            
            for _ in 0...3 {
                if frontIsClear {
                    move()
                }
            }
            
            turnLeft()
        }
        
    }
    
    // functions ________
    func turnLeft() {
        turnRight()
        turnRight()
        turnRight()
    }
    func turnBack() {
        turnRight()
        turnRight()
    }
    
    func moveFourtimes() {
        move()
        move()
        move()
        move()
    }
    //---
    func picThecandy() {
        if noCandyPresent
        {
            move()
        }
        else {
            pick()
        }
    }
    //--
    
    func putThecandy() {
        while  leftIsClear, frontIsClear {
            
            if noCandyPresent
            {
                put()
            }
            else {
                move()
            }
        }
    }
    //--
    func clearCandy() {
        
        while  rightIsClear, frontIsClear {
            
            if noCandyPresent {
                move()
            }
                
            else {
                pick()
            }
        }
    }
    
}







