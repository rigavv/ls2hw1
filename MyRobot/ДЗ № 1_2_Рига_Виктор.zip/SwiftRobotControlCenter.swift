//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L2C" //  Level name
        super.viewDidLoad()
    }
    
    override func run() {
        
        while  facingRight {
            if rightIsClear {
                findPick()
                riseUP()
                uTurn()
                comeDown()
            }
        }
    }
    
    func turnLeft() {
        turnRight()
        turnRight()
        turnRight()
    }
    
    func findPick() {
        while frontIsClear {
            move()
        }
        turnRight()
    }
    
    func riseUP() {
        while leftIsBlocked{
            if frontIsClear {
                move()
            }
            else {
                turnRight()
                turnRight()
                
                while noFacingLeft {
                        if frontIsClear {
                        move()
                    }
                }
               
            }
        }
    }
        
    func uTurn() {
        turnLeft()
        move()
        turnLeft()
    }
    
    func comeDown() {
        while frontIsClear {
            move()
        }
        turnRight()
    }
    
}
