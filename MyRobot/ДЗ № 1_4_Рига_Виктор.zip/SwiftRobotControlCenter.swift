
//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L55H" //  Level name
        super.viewDidLoad()
    }
    
    
    override func run() {
        
        while noCandyPresent || facingRight || facingLeft {
            putAndmove()
            if noCandyPresent, frontIsClear {
                move()
            }
            nextLineR()
            nextLineL()
            if rightIsBlocked {
                           break
                       }
            
        }
          

        
    } //end Run
    
// start block functions
 
    func nextLineR() {
        if frontIsBlocked, facingRight
        {
            turnRight()
            
            if noCandyPresent, frontIsClear {
            move()
            }
            turnRight()
        }
    }
    
    func nextLineL() {
          if frontIsBlocked, facingLeft, noCandyPresent
          {
              turnLeft()
              
              if noCandyPresent, frontIsClear {
              move()
              }
              turnLeft()
          }
      }
    

    
    func putAndmove() {
        if frontIsClear, noCandyPresent {
            put()
                if candyPresent, frontIsClear {
                    move()
                }
        }
        
    }
    
    func turnLeft() {
        turnRight()
        turnRight()
        turnRight()
    }
    
// end functions
    
   
    

    
    
} // End controller







