//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L4H" //  Level name
        super.viewDidLoad()
    }
    
    
    override func run() {
        
        move()
        turnRight()
        move()
        turnRight()
        turnRight()
        
        searchFirstangle()
        put()
        turnRight()
        move()
        while noCandyPresent {
            move()
            if candyPresent {
                break
            }
            if frontIsBlocked {
                put()
                turnRight()
                move()
            }
        }

    } //end Run
    
    // start block functions
    
    func searchFirstangle () {
        while frontIsClear
        {
            move()
            if frontIsBlocked
            {
                turnRight()
                while frontIsClear {
                    move()
                }
            }
        }
    }
    
    
    // end functions
    
} // End controller
