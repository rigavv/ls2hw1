//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L1C" //  Level name
        super.viewDidLoad()
    }
    
    var n = 0
    
    override func run() {
        move()
        
        while candyPresent {
                pick()
                n = n+1
            }
        for _ in 0...n-1 {
             put()
             put()
        }
            move()
    
        
    } //end Run
    
// start block functions
 
    
// end functions
    
    
} // End controller







