
//
//  SwiftRobotControlCenter.swift
//  MyRobot
//
//  Created by Ivan Vasilevich on 10/4/14.
//  Copyright (c) 2014 Ivan Besarab. All rights reserved.
//

import UIKit
//  All robot commands can be founded in GameViewController.h
class SwiftRobotControlCenter: RobotControlCenter {
    
    //  Level name setup
    override func viewDidLoad() {
        levelName = "L11C" //  Level name
        super.viewDidLoad()
    }
    
    
    override func run() {
        
       move()
       carryOverCandy()
       move()
       doubleCarryOverCandy()
          

        
    } //end Run
    
// start block functions
 
    
    func goBack() {
        back()
        move()
        back()
    }
    
    
    func turnLeft() {
        turnRight()
        turnRight()
        turnRight()
    }
    
    func back() {
    turnRight()
    turnRight()
    }
    
    func carryOverCandy () {
        while candyPresent {
                  pick()
                  move()
                  put()
                  goBack()
              }
    
    }
    func doubleCarryOverCandy () {
        while candyPresent {
                  pick()
                  back()
                  move()
                  put()
                  put()
                  back()
                  move()
              }
    
    }
    
// end functions
    
   
    
} // End controller







